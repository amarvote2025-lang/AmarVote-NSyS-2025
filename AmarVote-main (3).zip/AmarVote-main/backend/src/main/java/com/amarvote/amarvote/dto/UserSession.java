package com.amarvote.amarvote.dto;

public class UserSession {

    private String email;

    public UserSession(String email) {
        this.email = email;
    }
    public String getEmail() {
        return email;
    }

}
