package com.amarvote.amarvote.model;

// ElectionStatus.java
public enum ElectionStatus {
    DRAFT, ACTIVE, COMPLETED, CANCELLED
}