Here's a code 
<pre> ```python def hello(): print("Hello, world!") ``` </pre>