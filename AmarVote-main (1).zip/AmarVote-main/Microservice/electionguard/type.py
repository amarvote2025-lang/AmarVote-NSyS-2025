BallotId = str
ContestId = str
GuardianId = str
MediatorId = str
VerifierId = str
SelectionId = str
